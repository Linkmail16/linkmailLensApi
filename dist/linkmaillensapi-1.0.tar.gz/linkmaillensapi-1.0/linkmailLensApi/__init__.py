from .linkmailLensApi import lenSearchUrl, lenSearchImg

__version__ = "1.0"